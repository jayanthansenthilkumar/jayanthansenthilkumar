import { useEffect } from 'react';

export function useScrollReveal(dependency = null) {
  useEffect(() => {
    const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }
      });
    }, observerOptions);

    const selector = '.project-card, .blog-card, .about-widget, .contact-info-side, .contact-form-side, .about-image, .service-card';
    const animatedElements = document.querySelectorAll(selector);

    animatedElements.forEach((el) => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(20px)';
      el.style.transition = 'opacity 0.6s cubic-bezier(0.16, 1, 0.3, 1), transform 0.6s cubic-bezier(0.16, 1, 0.3, 1)';
      observer.observe(el);
    });

    return () => {
      observer.disconnect();
    };
  }, [dependency]);
}
