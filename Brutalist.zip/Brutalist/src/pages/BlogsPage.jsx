import { useScrollReveal } from '../hooks/useScrollReveal';

export function BlogsPage() {
  useScrollReveal();

  return (
    <main>
      <section className="page-header" style={{ backgroundColor: 'var(--secondary-color)', color: 'white' }}>
        <div className="page-title-wrapper">
          <h1 className="page-title" style={{ color: 'var(--text-color)' }}>THOUGHTS</h1>
        </div>
      </section>

      <section className="section-pad">
        <div className="grid-3">
          <a href="#" className="blog-card bg-pink" onClick={(e) => e.preventDefault()}>
            <div>
              <span className="blog-date">MAY 24, 2026</span>
              <h3>The Rise of Ultra-Brutalism in Web Design</h3>
            </div>
            <span className="read-more">Read Article &rarr;</span>
          </a>
          <a href="#" className="blog-card" onClick={(e) => e.preventDefault()}>
            <div>
              <span className="blog-date">MAY 15, 2026</span>
              <h3>Optimizing React Performance for Complex UIs</h3>
            </div>
            <span className="read-more">Read Article &rarr;</span>
          </a>
          <a href="#" className="blog-card bg-yellow" onClick={(e) => e.preventDefault()}>
            <div>
              <span className="blog-date">MAY 02, 2026</span>
              <h3>Mastering CSS Grid for Magazine Layouts</h3>
            </div>
            <span className="read-more">Read Article &rarr;</span>
          </a>
          <a href="#" className="blog-card" onClick={(e) => e.preventDefault()}>
            <div>
              <span className="blog-date">APR 20, 2026</span>
              <h3>Why Typography is 90% of Web Design</h3>
            </div>
            <span className="read-more">Read Article &rarr;</span>
          </a>
          <a href="#" className="blog-card bg-dark" onClick={(e) => e.preventDefault()}>
            <div>
              <span className="blog-date" style={{ borderColor: 'var(--bg-color)' }}>APR 10, 2026</span>
              <h3 style={{ color: 'white' }}>Building Accessible Components from Scratch</h3>
            </div>
            <span className="read-more" style={{ color: 'var(--accent-yellow)' }}>Read Article &rarr;</span>
          </a>
        </div>
      </section>
    </main>
  );
}
