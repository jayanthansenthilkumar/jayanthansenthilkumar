import { useScrollReveal } from '../hooks/useScrollReveal';

export function WorksPage() {
  useScrollReveal();

  return (
    <main>
      <section className="page-header" style={{ backgroundColor: 'var(--accent-pink)' }}>
        <div className="page-title-wrapper">
          <h1 className="page-title">MY WORKS</h1>
        </div>
      </section>

      <section className="section-pad">
        <div className="grid-3">
          {/* Project 1 */}
          <a
            href="https://github.com/prithikakannan/RockPaperScissor"
            target="_blank"
            rel="noreferrer"
            className="project-card"
          >
            <div className="project-img">
              <img
                src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop"
                alt="Rock Paper Scissors"
              />
            </div>
            <div className="project-info">
              <h3>Rock Paper Scissors</h3>
              <p>Interactive Rock Paper Scissors game with custom GUI and game logic supporting single player mode with scoring.</p>
              <div className="project-tags">
                <span className="tag-sm">Python</span>
                <span className="tag-sm">CustomTkinter</span>
                <span className="tag-sm">Random</span>
              </div>
            </div>
          </a>

          {/* Project 2 */}
          <a
            href="https://github.com/prithikakannan/UndoRedo"
            target="_blank"
            rel="noreferrer"
            className="project-card bg-yellow"
          >
            <div className="project-img">
              <img
                src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=2670&auto=format&fit=crop"
                alt="Undo Redo Mechanism"
              />
            </div>
            <div className="project-info">
              <h3>Undo & Redo Mechanism</h3>
              <p>A console-based implementation of Undo and Redo operations using stacks in C with push/pop memory management.</p>
              <div className="project-tags">
                <span className="tag-sm">C</span>
                <span className="tag-sm">Stacks</span>
                <span className="tag-sm">Data Structures</span>
                <span className="tag-sm">Pointers</span>
              </div>
            </div>
          </a>

          {/* Project 3 */}
          <a
            href="https://github.com/prithikakannan"
            target="_blank"
            rel="noreferrer"
            className="project-card bg-blue"
          >
            <div className="project-img">
              <img
                src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=2672&auto=format&fit=crop"
                alt="Prithika - Personal Portfolio"
              />
            </div>
            <div className="project-info">
              <h3 style={{ color: 'white' }}>Prithika - Personal Portfolio</h3>
              <p style={{ color: 'white' }}>A responsive personal portfolio showcasing projects, technical skills, and experience.</p>
              <div className="project-tags">
                <span className="tag-sm" style={{ color: 'var(--text-color)' }}>
                  React
                </span>
                <span className="tag-sm" style={{ color: 'var(--text-color)' }}>
                  TypeScript
                </span>
                <span className="tag-sm" style={{ color: 'var(--text-color)' }}>
                  Tailwind CSS
                </span>
              </div>
            </div>
          </a>

          {/* Project 4 */}
          <a href="#" onClick={(e) => e.preventDefault()} className="project-card bg-dark">
            <div className="project-img">
              <img
                src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2670&auto=format&fit=crop"
                alt="PrisolTech Website"
              />
            </div>
            <div className="project-info">
              <h3 style={{ color: 'white' }}>PrisolTech Website</h3>
              <p style={{ color: 'white' }}>An official website for PrisolTech showcasing services, portfolio, team, and integrated contact form.</p>
              <div className="project-tags">
                <span className="tag-sm">React</span>
                <span className="tag-sm">Node.js</span>
                <span className="tag-sm">EmailJS</span>
              </div>
            </div>
          </a>

          {/* Project 5 */}
          <a href="#" onClick={(e) => e.preventDefault()} className="project-card">
            <div className="project-img">
              <img
                src="https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?q=80&w=2676&auto=format&fit=crop"
                alt="Full Stack Management App"
              />
            </div>
            <div className="project-info">
              <h3>Full-Stack Management App</h3>
              <p>Scalable web application managing user operations and secure API authentication workflows.</p>
              <div className="project-tags">
                <span className="tag-sm">React</span>
                <span className="tag-sm">Express</span>
                <span className="tag-sm">MongoDB</span>
              </div>
            </div>
          </a>

          {/* Project 6 */}
          <a href="#" onClick={(e) => e.preventDefault()} className="project-card bg-pink">
            <div className="project-img">
              <img
                src="https://images.unsplash.com/photo-1558655146-d09347e92766?q=80&w=2664&auto=format&fit=crop"
                alt="Interactive GUI Tool"
              />
            </div>
            <div className="project-info">
              <h3>Interactive Python GUI Tools</h3>
              <p>Desktop applications featuring reactive user interfaces, custom event handlers, and data visualization.</p>
              <div className="project-tags">
                <span className="tag-sm">Python</span>
                <span className="tag-sm">CustomTkinter</span>
                <span className="tag-sm">GUI</span>
              </div>
            </div>
          </a>
        </div>
      </section>
    </main>
  );
}
