import { useScrollReveal } from '../hooks/useScrollReveal';

export function AboutPage() {
  useScrollReveal();

  return (
    <main>
      <section className="page-header">
        <div className="page-title-wrapper">
          <h1 className="page-title">ABOUT ME</h1>
        </div>
      </section>

      <section className="section-pad">
        <div className="grid-2">
          <div
            className="premium-card"
            style={{
              width: '100%',
              maxWidth: '100%',
              boxShadow: 'var(--shadow-offset) var(--shadow-offset) 0px var(--accent-pink)',
            }}
          >
            <div className="card-img-container" style={{ height: '500px', padding: 0 }}>
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1000&auto=format&fit=crop"
                alt="Prithika Kannan"
                style={{ height: '100%', border: 'none' }}
              />
            </div>
          </div>
          <div>
            <h2 className="section-title" style={{ fontSize: '2.5rem', marginBottom: '2rem' }}>
              Designing with Purpose.<br />Engineering with Precision.
            </h2>
            <p style={{ fontSize: '1.1rem', marginBottom: '1.5rem', opacity: 0.9 }}>
              I am Prithika Kannan, a Full Stack Web Developer based in Dharmapuri, Tamil Nadu. I bridge the gap between intuitive UI design and robust software engineering, crafting memorable web applications that solve real-world problems.
            </p>
            <p style={{ fontSize: '1.1rem', marginBottom: '2.5rem', opacity: 0.9 }}>
              My technical expertise spans frontend frameworks like React and TypeScript to backend development with Node.js, Express, C, Python, and efficient database architectures. I focus on creating performant, accessible, and clean software solutions.
            </p>

            <h3 style={{ marginBottom: '1rem', fontSize: '1.5rem' }}>Core Stack</h3>
            <div className="project-tags">
              <span className="tag">React / Next.js</span>
              <span className="tag bg-yellow">Node.js / Express</span>
              <span className="tag bg-pink">TypeScript</span>
              <span className="tag bg-blue">Python / CustomTkinter</span>
              <span className="tag">C / Data Structures</span>
              <span className="tag bg-yellow">Tailwind CSS</span>
              <span className="tag bg-pink">EmailJS</span>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
