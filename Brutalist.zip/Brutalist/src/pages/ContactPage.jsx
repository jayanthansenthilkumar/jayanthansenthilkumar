import { useState, useRef, useEffect } from 'react';
import emailjs from '@emailjs/browser';
import { useScrollReveal } from '../hooks/useScrollReveal';

export function ContactPage() {
  useScrollReveal();
  const formRef = useRef(null);

  const [btnState, setBtnState] = useState({
    text: 'Send Transmission',
    style: {},
  });
  const [formData, setFormData] = useState({
    user_name: '',
    user_email: '',
    message: '',
  });

  useEffect(() => {
    emailjs.init({
      publicKey: 'YOUR_PUBLIC_KEY',
    });
  }, []);

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const originalText = 'Send Transmission';

    setBtnState({
      text: 'TRANSMITTING...',
      style: { opacity: 0.8 },
    });

    emailjs
      .sendForm('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', formRef.current)
      .then(() => {
        setBtnState({
          text: 'TRANSMITTED SUCCESSFULLY',
          style: {
            backgroundColor: 'var(--accent-green, #8BE8E5)',
            color: 'var(--text-color)',
            opacity: 1,
          },
        });
        setFormData({ user_name: '', user_email: '', message: '' });

        setTimeout(() => {
          setBtnState({
            text: originalText,
            style: { backgroundColor: 'var(--primary-color)', color: 'white' },
          });
        }, 4000);
      })
      .catch((error) => {
        console.log('FAILED...', error);
        if (error?.text === 'The public key is required.' || error?.status === 400) {
          alert('EmailJS is not configured. Please add your Public Key, Service ID, and Template ID.');
        }
        setBtnState({
          text: 'TRANSMISSION FAILED',
          style: { backgroundColor: 'red', color: 'white', opacity: 1 },
        });

        setTimeout(() => {
          setBtnState({
            text: originalText,
            style: { backgroundColor: 'var(--primary-color)' },
          });
        }, 4000);
      });
  };

  return (
    <main>
      <section className="page-header" style={{ backgroundColor: 'var(--accent-yellow)' }}>
        <div className="page-title-wrapper">
          <h1 className="page-title">LET'S TALK</h1>
        </div>
      </section>

      <section className="section-pad" style={{ backgroundColor: 'var(--bg-color)' }}>
        <div className="contact-grid">
          <div className="contact-info-side">
            <h2>
              Initiate<br />Protocol.
            </h2>
            <p>Have an idea that breaks the mold? Let's build it. Fill out the form or reach out directly.</p>
            <div style={{ marginTop: '2rem' }}>
              <strong>EMAIL</strong>
              <br />
              <a
                href="mailto:prithikakannan3012@gmail.com"
                style={{ color: 'var(--text-color)', textDecoration: 'none', fontSize: '1.2rem' }}
              >
                prithikakannan3012@gmail.com
              </a>
            </div>
            <div style={{ marginTop: '1.5rem' }}>
              <strong>LOCATION</strong>
              <br />
              <span style={{ fontSize: '1.1rem', fontWeight: 600 }}>Dharmapuri, Tamil Nadu.</span>
            </div>
            <div style={{ marginTop: '1.5rem' }}>
              <strong>SOCIALS</strong>
              <br />
              <a
                href="https://github.com/prithikakannan"
                target="_blank"
                rel="noreferrer"
                style={{ color: 'var(--text-color)', marginRight: '1rem', textDecoration: 'none', borderBottom: '2px solid var(--text-color)' }}
              >
                GITHUB
              </a>
              <a
                href="https://linkedin.com/in/prithikakannan"
                target="_blank"
                rel="noreferrer"
                style={{ color: 'var(--text-color)', marginRight: '1rem', textDecoration: 'none', borderBottom: '2px solid var(--text-color)' }}
              >
                LINKEDIN
              </a>
              <a
                href="https://twitter.com/prithikakannan"
                target="_blank"
                rel="noreferrer"
                style={{ color: 'var(--text-color)', textDecoration: 'none', borderBottom: '2px solid var(--text-color)' }}
              >
                TWITTER
              </a>
            </div>
          </div>
          <div className="contact-form-side">
            <form ref={formRef} id="contact-form" onSubmit={handleSubmit}>
              <input type="hidden" name="to_name" value="Prithika Kannan" />

              <div className="form-group">
                <label>Name</label>
                <input
                  type="text"
                  name="user_name"
                  placeholder="Prithika Kannan"
                  value={formData.user_name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label>Email</label>
                <input
                  type="email"
                  name="user_email"
                  placeholder="prithikakannan3012@gmail.com"
                  value={formData.user_email}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label>Project Details</label>
                <textarea
                  name="message"
                  placeholder="Tell me about your vision..."
                  rows="6"
                  value={formData.message}
                  onChange={handleChange}
                  required
                ></textarea>
              </div>
              <button
                type="submit"
                className="btn-primary large w-100"
                id="submit-btn"
                style={btnState.style}
              >
                {btnState.text}
              </button>
            </form>
          </div>
        </div>
      </section>
    </main>
  );
}
