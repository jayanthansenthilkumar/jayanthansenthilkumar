import { Link, useNavigate } from 'react-router-dom';
import { HeroClock } from '../components/HeroClock';
import { useScrollReveal } from '../hooks/useScrollReveal';

export function HomePage() {
  const navigate = useNavigate();
  useScrollReveal();

  const handleHomeContactProceed = (e) => {
    e.preventDefault();
    navigate('/contact');
  };

  return (
    <main>
      {/* Premium Hero */}
      <section className="hero">
        <div className="hero-left">
          <div className="availability-badge">
            <span className="dot"></span> Open for new projects
          </div>
          <h1 className="hero-title">
            PRITHIKA<br />KANNAN &<br />
            <span className="outlined">DEVELOPER</span>
          </h1>
          <p className="hero-desc">
            Full-stack developer passionate about creating exceptional digital experiences that solve real-world problems. Specializing in modern web technologies and innovative solutions.
          </p>
          <div className="hero-actions">
            <Link to="/works" className="btn-primary large">
              Explore Works
            </Link>
            <Link to="/contact" className="btn-secondary large">
              Get in Touch
            </Link>
          </div>
        </div>
        <div className="hero-right">
          <div className="premium-card">
            <div className="card-header">
              <span className="circle"></span>
              <span className="circle"></span>
              <span className="circle"></span>
            </div>
            <div className="card-img-container">
              <img
                src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop"
                alt="Prithika Kannan Portfolio"
              />
            </div>
            <div className="card-footer">
              <span>SYS.RDY // 2026</span>
              <HeroClock />
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="section-pad bg-dark">
        <div className="section-header">
          <h2 className="section-title" style={{ color: 'white' }}>
            Capabilities
          </h2>
          <Link
            to="/about"
            className="view-all"
            style={{ color: 'var(--accent-yellow)', borderColor: 'var(--accent-yellow)' }}
          >
            More About Me
          </Link>
        </div>
        <div className="services-grid">
          <div className="service-card">
            <div className="service-icon">✦</div>
            <h3>Frontend Dev</h3>
            <p>
              Building responsive, high-performance web applications using React, TypeScript, Tailwind CSS, and modern web standards.
            </p>
          </div>
          <div className="service-card bg-pink">
            <div className="service-icon">⚡</div>
            <h3>Backend Dev</h3>
            <p>
              Developing scalable server architectures, RESTful APIs, and robust database solutions using Node.js, Express, and databases.
            </p>
          </div>
          <div className="service-card bg-blue">
            <div className="service-icon">⚙️</div>
            <h3>Full-Stack Solutions</h3>
            <p>
              End-to-end application development bridging intuitive frontend UI with reliable, production-ready backend infrastructure.
            </p>
          </div>
        </div>
      </section>

      {/* Works Section Preview */}
      <section className="section-pad">
        <div className="section-header">
          <h2 className="section-title">Selected Works</h2>
          <Link to="/works" className="view-all">
            View All Projects
          </Link>
        </div>
        <div className="grid-3">
          <a
            href="https://github.com/prithikakannan/RockPaperScissor"
            target="_blank"
            rel="noreferrer"
            className="project-card"
          >
            <div className="project-img">
              <img
                src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop"
                alt="Rock Paper Scissors Game"
              />
            </div>
            <div className="project-info">
              <h3>Rock Paper Scissors</h3>
              <p>Interactive game with custom UI and computer scoring logic.</p>
              <div className="project-tags">
                <span className="tag-sm">Python</span>
                <span className="tag-sm">CustomTkinter</span>
                <span className="tag-sm">GUI</span>
              </div>
            </div>
          </a>
          <a
            href="https://github.com/prithikakannan/UndoRedo"
            target="_blank"
            rel="noreferrer"
            className="project-card bg-yellow"
          >
            <div className="project-img">
              <img
                src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=2670&auto=format&fit=crop"
                alt="Undo Redo Mechanism"
              />
            </div>
            <div className="project-info">
              <h3>Undo & Redo Mechanism</h3>
              <p>Console-based stack data structure implementation in C.</p>
              <div className="project-tags">
                <span className="tag-sm">C</span>
                <span className="tag-sm">Stacks</span>
                <span className="tag-sm">Data Structures</span>
              </div>
            </div>
          </a>
          <Link to="/works" className="project-card bg-blue">
            <div className="project-img">
              <img
                src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2670&auto=format&fit=crop"
                alt="PrisolTech Website"
              />
            </div>
            <div className="project-info">
              <h3 style={{ color: 'white' }}>PrisolTech Website</h3>
              <p style={{ color: 'white' }}>Official company site with services & contact form.</p>
              <div className="project-tags">
                <span className="tag-sm" style={{ color: 'var(--text-color)' }}>
                  React
                </span>
                <span className="tag-sm" style={{ color: 'var(--text-color)' }}>
                  Node.js
                </span>
                <span className="tag-sm" style={{ color: 'var(--text-color)' }}>
                  EmailJS
                </span>
              </div>
            </div>
          </Link>
        </div>
      </section>

      {/* About Section Preview */}
      <section className="section-pad">
        <div className="grid-2">
          <div className="about-widget">
            <h2>Meet Prithika.</h2>
            <p>
              I am a full-stack developer based in Dharmapuri, Tamil Nadu. I specialize in building responsive web applications, scalable backends, and technical solutions with clean, maintainable code.
            </p>
            <Link
              to="/about"
              className="btn-primary"
              style={{ width: 'fit-content', background: 'white', color: 'var(--text-color)' }}
            >
              Read Full Story
            </Link>
          </div>
          <div
            className="about-image"
            style={{
              border: 'var(--border-width) solid var(--border-color)',
              background:
                "url('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1000&auto=format&fit=crop') center/cover",
              minHeight: '400px',
              boxShadow: 'var(--shadow-offset) var(--shadow-offset) 0px var(--accent-yellow)',
            }}
          ></div>
        </div>
      </section>

      {/* Blogs Section Preview */}
      <section className="section-pad">
        <div className="section-header">
          <h2 className="section-title">Latest Writing</h2>
          <Link to="/blogs" className="view-all">
            Read All Blogs
          </Link>
        </div>
        <div className="grid-3">
          <Link to="/blogs" className="blog-card bg-pink">
            <div>
              <span className="blog-date">MAY 24, 2026</span>
              <h3>Building Scalable Web Applications with React & Node.js</h3>
            </div>
            <span className="read-more">Read Article &rarr;</span>
          </Link>
          <Link to="/blogs" className="blog-card">
            <div>
              <span className="blog-date">MAY 15, 2026</span>
              <h3>Mastering Data Structures: Stacks, Queues, & Pointers in C</h3>
            </div>
            <span className="read-more">Read Article &rarr;</span>
          </Link>
          <Link to="/blogs" className="blog-card bg-dark">
            <div>
              <span className="blog-date" style={{ borderColor: 'var(--bg-color)' }}>
                MAY 02, 2026
              </span>
              <h3 style={{ color: 'white' }}>Designing Intuitive GUIs with Python & CustomTkinter</h3>
            </div>
            <span className="read-more" style={{ color: 'var(--accent-yellow)' }}>
              Read Article &rarr;
            </span>
          </Link>
        </div>
      </section>

      {/* Contact Section Preview */}
      <section className="section-pad">
        <div className="section-header">
          <h2 className="section-title">Initiate Protocol</h2>
          <Link to="/contact" className="view-all">
            Go to Contact Page
          </Link>
        </div>
        <div className="contact-grid">
          <div className="contact-info-side">
            <h2>
              Let's build<br />it.
            </h2>
            <p>Have an idea that breaks the mold? Fill out the form or reach out directly.</p>
            <div style={{ marginTop: '2rem' }}>
              <strong>EMAIL</strong>
              <br />
              <a
                href="mailto:prithikakannan3012@gmail.com"
                style={{ color: 'var(--text-color)', textDecoration: 'none', fontSize: '1.2rem' }}
              >
                prithikakannan3012@gmail.com
              </a>
            </div>
          </div>
          <div className="contact-form-side">
            <form id="contact-form-home" onSubmit={handleHomeContactProceed}>
              <div className="form-group">
                <label>Name</label>
                <input type="text" name="user_name" placeholder="John Doe" required />
              </div>
              <div className="form-group">
                <label>Email</label>
                <input type="email" name="user_email" placeholder="john@example.com" required />
              </div>
              <button type="submit" className="btn-primary large w-100">
                Proceed to Transmission
              </button>
            </form>
          </div>
        </div>
      </section>
    </main>
  );
}
