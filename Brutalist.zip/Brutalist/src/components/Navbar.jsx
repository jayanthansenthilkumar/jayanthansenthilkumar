import { Link, NavLink } from 'react-router-dom';

export function Navbar() {
  return (
    <nav className="navbar">
      <Link to="/" className="logo">PRITHIKA.</Link>
      <ul className="nav-links">
        <li>
          <NavLink to="/" className={({ isActive }) => (isActive ? 'active' : '')}>
            Home
          </NavLink>
        </li>
        <li>
          <NavLink to="/about" className={({ isActive }) => (isActive ? 'active' : '')}>
            About
          </NavLink>
        </li>
        <li>
          <NavLink to="/works" className={({ isActive }) => (isActive ? 'active' : '')}>
            Works
          </NavLink>
        </li>
        <li>
          <NavLink to="/blogs" className={({ isActive }) => (isActive ? 'active' : '')}>
            Blogs
          </NavLink>
        </li>
        <li>
          <NavLink to="/contact" className={({ isActive }) => (isActive ? 'active' : '')}>
            Contact
          </NavLink>
        </li>
      </ul>
      <Link to="/contact" className="btn-primary">Hire Me</Link>
    </nav>
  );
}
