export function Footer() {
  return (
    <footer className="footer">
      <div className="copyright">&copy; 2026 Prithika Kannan. All rights reserved.</div>
      <div className="socials">
        <a href="https://github.com/prithikakannan" target="_blank" rel="noreferrer">Github</a>
        <a href="https://linkedin.com/in/prithikakannan" target="_blank" rel="noreferrer">LinkedIn</a>
        <a href="https://twitter.com/prithikakannan" target="_blank" rel="noreferrer">Twitter</a>
      </div>
    </footer>
  );
}
